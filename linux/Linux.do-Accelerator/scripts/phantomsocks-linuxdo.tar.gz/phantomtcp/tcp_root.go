//go:build pcap || rawsocket || windivert

package phantomtcp

import (
	"crypto/rand"
	"errors"
	"io"
	mathrand "math/rand"
	"net"
	"sync"
	"time"

	"github.com/google/gopacket"
	"github.com/google/gopacket/layers"
)

type ConnectionInfo struct {
	Link gopacket.LinkLayer
	IP   gopacket.NetworkLayer
	TCP  layers.TCP
}

type SynInfo struct {
	Number uint32
	Hint   uint32
}

var ConnSyn sync.Map
var ConnInfo4 [65536]chan *ConnectionInfo
var ConnInfo6 [65536]chan *ConnectionInfo

func AddConn(synAddr string, hint uint32) {
	result, ok := ConnSyn.LoadOrStore(synAddr, SynInfo{1, hint})
	if ok {
		info := result.(SynInfo)
		info.Number++
		info.Hint = hint
		ConnSyn.Store(synAddr, info)
	}
}

func DelConn(synAddr string) {
	result, ok := ConnSyn.Load(synAddr)
	if ok {
		info := result.(SynInfo)
		if info.Number > 1 {
			info.Number--
			ConnSyn.Store(synAddr, info)
		} else {
			ConnSyn.Delete(synAddr)
		}
	}
}

func (synpacket *ConnectionInfo)AddTCPSeq(seq uint32) {
	synpacket.TCP.Seq += seq
}

func (outbound *Outbound) dial(host string, port int, b []byte, offset int, length int) (net.Conn, *ConnectionInfo, error) {
	var conn net.Conn
	raddrs, err := outbound.GetRemoteAddresses(host, port)
	if err != nil {
		return nil, nil, err
	}

	connect_err := errors.New("connection does not exist")
	device := outbound.Device
	hint := outbound.Hint

	if hint&HINT_FAKE == 0 {
		raddr := raddrs[mathrand.Intn(len(raddrs))]
		var laddr *net.TCPAddr = nil
		if device != "" {
			laddr, err = GetLocalTCPAddr(device, raddr.IP.To4() == nil)
			if err != nil {
				return nil, nil, err
			}
		}

		tfo := hint&HINT_TFO != 0
		keepalive := hint&HINT_KEEPALIVE != 0

		startTime := time.Now().UnixMilli()
		conn, err = DialWithOption(laddr, raddr, 0, 0, tfo, keepalive, time.Second)

		if tfo && err == nil {
			delay := time.Now().UnixMilli() - startTime
			if delay > 0 {
				conn.Close()
				startTime := time.Now().UnixMilli()
				conn, err = DialWithOption(laddr, raddr, 0, 0, tfo, keepalive, time.Second)
				if time.Now().UnixMilli()-startTime > 0 {
					return nil, nil, errors.New("tcp fastopen failed")
				}
			}
		}

		if err != nil {
			return nil, nil, err
		}

		proxyConn, err := outbound.ProxyHandshake(conn, nil, host, port)

		if err == nil && b != nil {
			SegOffset := 0
			cut := offset + length/2
			if cut > 4 {
				if hint&(HINT_TCPFRAG) != 0 {
					_, err = conn.Write(b[SegOffset:1])
					if err == nil {
						if hint&(HINT_OOB) != 0 {
							err = SendWithOption(conn, b[1:3], b[3:4], 0, 0)
						} else {
							_, err = conn.Write(b[1:4])
						}
						SegOffset += 4
					}
				}

				if hint&(HINT_OOB) != 0 {
					oob := []byte{0}
					cut := offset + length/2
					if cut > 4 && hint&HINT_OOB != 0 {
						err = SendWithOption(conn, b[SegOffset:cut], oob, 0, 0)
						SegOffset = cut
					}
				}
			}

			if err == nil {
				_, err = conn.Write(b[SegOffset:])
			}
		}

		if err != nil {
			conn.Close()
			return nil, nil, err
		}

		return proxyConn, nil, err
	} else {
		send_magic_packet := func(connInfo *ConnectionInfo, payload []byte, hint uint32, ttl uint8, count int) error {
			var mss uint32 = 1220
			var segment uint32 = 0
			var totalLen uint32 = uint32(len(payload))
			initSeq := connInfo.TCP.Seq
			for totalLen-segment > 1220 {
				err := ModifyAndSendPacket(connInfo, payload[segment:segment+mss], hint, ttl, count)
				if err != nil {
					return err
				}
				segment += mss
				connInfo.TCP.Seq += mss
				time.Sleep(10 * time.Millisecond)
			}
			err = ModifyAndSendPacket(connInfo, payload[segment:], hint, ttl, count)
			connInfo.TCP.Seq = initSeq
			time.Sleep(10 * time.Millisecond)
			return err
		}

		if PassiveMode {
			raddr := raddrs[mathrand.Intn(len(raddrs))]

			var laddr *net.TCPAddr = nil
			if device != "" {
				laddr, err = GetLocalTCPAddr(device, raddr.IP.To4() == nil)
				if err != nil {
					return nil, nil, err
				}
			}

			conn, err = net.DialTCP("tcp", laddr, raddr)
			if err == nil {
				conn, err = outbound.ProxyHandshake(conn, nil, host, port)
			}

			if err == nil && b != nil {
				if length > 0 {
					cut := offset + length/2
					tos := 1 << 2
					if hint&HINT_TTL != 0 {
						tos = int(outbound.TTL) << 2
					}
					if SendWithOption(conn, b[:cut], nil, tos, 1) == nil {
						_, err = conn.Write(b[cut:])
					}
				} else {
					_, err = conn.Write(b)
				}
			}

			if err != nil {
				conn.Close()
				return nil, nil, err
			}

			return conn, nil, err
		} else {
			start_time := time.Now()

			if offset == 0 {
				length = len(b)
				hint |= HINT_RAND
			}

			fakepaylen := len(b)
			fakepayload := make([]byte, fakepaylen)
			copy(fakepayload, b[:fakepaylen])

			cut := offset + length/2
			var tfo_payload []byte = nil
			if hint&HINT_TFO != 0 {
				if hint&HINT_TCPFRAG != 0 {
					tfo_payload = b[:cut]
				} else {
					tfo_payload = b
				}
			} else if hint&HINT_RAND != 0 {
				_, err = rand.Read(fakepayload)
				if err != nil {
					logPrintln(1, err)
				}
			} else {
				min_dot := offset + length
				max_dot := offset
				for i := offset; i < offset+length; i++ {
					if fakepayload[i] == '.' {
						if i < min_dot {
							min_dot = i
						}
						if i > max_dot {
							max_dot = i
						}
					} else {
						fakepayload[i] = domainBytes[mathrand.Intn(len(domainBytes))]
					}
				}
				if min_dot == max_dot {
					min_dot = offset
				}

				cut = (min_dot + max_dot) / 2
			}

			var synpacket *ConnectionInfo
			for i := 0; i < len(raddrs); i++ {
				raddr := raddrs[i]
				laddr, err := GetLocalTCPAddr(device, raddr.IP.To4() == nil)
				if err != nil {
					return nil, nil, errors.New("invalid device")
				}

				conn, synpacket, err = DialConnInfo(laddr, raddr, outbound, tfo_payload)
				if err != nil {
					if IsNormalError(err) {
						continue
					}
					return nil, nil, err
				}

				break
			}

			if synpacket == nil {
				if conn != nil {
					conn.Close()
				}
				return nil, nil, connect_err
			}

			logPrintln(3, host, conn.RemoteAddr(), "connected", time.Since(start_time))

			if (hint & HINT_DELAY) != 0 {
				time.Sleep(time.Second)
			}

			synpacket.TCP.Seq++

			if outbound.Protocol != 0 {
				conn, err = outbound.ProxyHandshake(conn, synpacket, host, port)
				if err != nil {
					conn.Close()
					return nil, nil, err
				}
				if outbound.Protocol == HTTPS {
					conn.Write(b)
					return conn, synpacket, nil
				}
			}

			count := 1
			if hint&HINT_TFO != 0 {
				if hint&HINT_TCPFRAG != 0 {
					if _, err = conn.Write(b[cut:]); err != nil {
						conn.Close()
						return nil, nil, err
					}
				}
				synpacket.TCP.Seq += uint32(len(b))
			} else {
				SegOffset := 0
				if err = send_magic_packet(synpacket, fakepayload, hint, outbound.TTL, count); err != nil {
					conn.Close()
					return nil, nil, err
				}

				if hint&(HINT_TCPFRAG) != 0 && cut > 4 {
					SegOffset = 4
					if _, err = conn.Write(b[:1]); err == nil {
						_, err = conn.Write(b[1:4])
					}
					if err != nil {
						conn.Close()
						return nil, nil, err
					}
				}

				if hint&HINT_REVERSE != 0 {
					synpacket.TCP.Seq += uint32(cut)
					if err = send_magic_packet(synpacket, b[cut:], HINT_NONE, 64, count); err != nil {
						conn.Close()
						return nil, nil, err
					}

					if _, err = conn.Write(b[SegOffset:cut]); err != nil {
						conn.Close()
						return nil, nil, err
					}

					if _, err = conn.Write(fakepayload[cut:]); err != nil {
						conn.Close()
						return nil, nil, err
					}

					synpacket.TCP.Seq += uint32(len(b) - cut)
				} else {
					if _, err = conn.Write(b[SegOffset:cut]); err != nil {
						conn.Close()
						return nil, nil, err
					}

					if err = send_magic_packet(synpacket, fakepayload, hint, outbound.TTL, count); err != nil {
						conn.Close()
						return nil, nil, err
					}

					if _, err = conn.Write(b[cut:]); err != nil {
						conn.Close()
						return nil, nil, err
					}

					synpacket.TCP.Seq += uint32(len(b))
				}

				if hint&HINT_SAT != 0 {
					_, err = rand.Read(fakepayload)
					if err != nil {
						conn.Close()
						return nil, nil, err
					}
					err = send_magic_packet(synpacket, fakepayload, hint, outbound.TTL, 2)
				}
			}

			return conn, synpacket, err
		}
	}
}

func (outbound *Outbound) Keep(client, conn net.Conn, connInfo *ConnectionInfo) {
	fakepayload := make([]byte, 1500)

	go func() {
		var b [1460]byte
		for {
			n, err := client.Read(b[:])
			if err != nil {
				conn.Close()
				return
			}

			err = ModifyAndSendPacket(connInfo, fakepayload, outbound.Hint, outbound.TTL, 2)
			if err != nil {
				conn.Close()
				return
			}
			_, err = conn.Write(b[:n])
			if err != nil {
				conn.Close()
				return
			}
			connInfo.TCP.Seq += uint32(n)
		}
	}()

	io.Copy(client, conn)
}