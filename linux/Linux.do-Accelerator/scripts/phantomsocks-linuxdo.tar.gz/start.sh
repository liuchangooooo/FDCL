#!/bin/bash

cd "$(dirname "$0")"

# 自动检测网卡
DEVICE=$(ip route get 8.8.8.8 2>/dev/null | awk '{for(i=1;i<=NF;i++) if($i=="dev") print $(i+1)}' | head -1)
if [ -z "$DEVICE" ]; then
    echo "无法检测网卡，请手动修改 config.json 中的 device 字段"
    exit 1
fi

# 更新 config.json 中的网卡名
sed -i "s/\"device\": \"[^\"]*\"/\"device\": \"$DEVICE\"/" config.json

# 编译（如果没有二进制）
if [ ! -f phantomsocks ]; then
    echo "编译中..."
    go build -tags rawsocket -o phantomsocks
fi

echo "网卡: $DEVICE"
echo "代理: socks5://127.0.0.1:1080"
echo "启动 phantomsocks..."
sudo ./phantomsocks -log 1
