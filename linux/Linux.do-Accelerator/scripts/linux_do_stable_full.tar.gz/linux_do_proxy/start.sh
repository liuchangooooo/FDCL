#!/bin/bash
# Get the directory of the script
DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
PORT=10810

echo "Stopping any existing proxy on port $PORT..."
echo "lxmmfjh1997" | sudo -S fuser -k $PORT/tcp 2>/dev/null || true
sleep 1

echo "Starting Linux.do Stable Proxy on 127.0.0.1:$PORT..."
# Ensure we are running from the script directory
cd "$DIR"
echo "lxmmfjh1997" | sudo -S ./demergi/bin/demergi.js --https-clienthello-size 1 --doh-url https://aaa.ddd.oaifree.com/query-dns -A 127.0.0.1:$PORT
