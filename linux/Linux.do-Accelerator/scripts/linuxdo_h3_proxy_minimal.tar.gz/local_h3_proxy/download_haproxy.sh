#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
PKG_DIR="$BASE_DIR/pkg"
DIST_DIR="$BASE_DIR/haproxy-dist"

HAPROXY_URL="${HAPROXY_URL:-https://www.haproxy.com/download/haproxy/performance/ubuntu/ha33/pool/main/h/haproxy-awslc/haproxy-awslc_3.3.6-0+ha33+ubuntu24.04u3_amd64.deb}"
AWSLC_URL="${AWSLC_URL:-https://www.haproxy.com/download/haproxy/performance/ubuntu/ha33/pool/main/a/awslc/libssl-awslc_3.3.0-0+ha33+ubuntu24.04u1_amd64.deb}"

mkdir -p "$PKG_DIR" "$DIST_DIR"
cd "$PKG_DIR"

curl -L --fail --retry 3 -O "$HAPROXY_URL"
curl -L --fail --retry 3 -O "$AWSLC_URL"

apt download libopentracing-c-wrapper0t64 libopentracing1 libjemalloc2 >/dev/null

rm -rf "$DIST_DIR"/*
dpkg-deb -x haproxy-awslc_*.deb "$DIST_DIR"
dpkg-deb -x libssl-awslc_*.deb "$DIST_DIR"
dpkg-deb -x libopentracing-c-wrapper0t64_*.deb "$DIST_DIR"
dpkg-deb -x libopentracing1_*.deb "$DIST_DIR"
dpkg-deb -x libjemalloc2_*.deb "$DIST_DIR"

LD_LIBRARY_PATH="$DIST_DIR/opt/aws-lc/lib/x86_64-linux-gnu:$DIST_DIR/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu" \
  "$DIST_DIR/usr/sbin/haproxy" -vv | sed -n '1,20p'
