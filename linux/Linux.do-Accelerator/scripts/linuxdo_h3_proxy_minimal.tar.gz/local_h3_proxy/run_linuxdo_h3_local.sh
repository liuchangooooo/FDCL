#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$BASE_DIR/haproxy.pid"
LOG_FILE="$BASE_DIR/haproxy.log"
CFG_FILE="$BASE_DIR/haproxy.cfg"
PEM_FILE="$BASE_DIR/certs/linuxdo.pem"
DOMAINS_FILE="$BASE_DIR/managed_domains.txt"
BRIDGE_PID_FILE="$BASE_DIR/bridge.pid"
BRIDGE_LOG_FILE="$BASE_DIR/bridge.log"
LISTEN_HOST="${LISTEN_HOST:-127.0.0.1}"
LISTEN_PORT="${LISTEN_PORT:-443}"
DOH_URL="${DOH_URL:-https://aaa.ddd.oaifree.com/query-dns}"
DOH_NAMES="${DOH_NAMES:-}"
RRTYPES="${RRTYPES:-A}"
BRIDGE_HOST="${BRIDGE_HOST:-127.0.0.1}"
BRIDGE_PORT="${BRIDGE_PORT:-18080}"
SELF_PATH="$(readlink -f "$0")"

need_root() {
  if (( LISTEN_PORT < 1024 )); then
    return 0
  fi
  if [[ ! -w /etc/hosts ]]; then
    return 0
  fi
  return 1
}

reexec_with_sudo() {
  exec sudo -E bash "$SELF_PATH" "$@"
}

stop_existing_instance() {
  if [[ -f "$PID_FILE" ]] && kill -0 "$(cat "$PID_FILE")" 2>/dev/null; then
    kill "$(cat "$PID_FILE")" || true
    sleep 1
  fi
  rm -f "$PID_FILE"
}

stop_bridge_instance() {
  if [[ -f "$BRIDGE_PID_FILE" ]] && kill -0 "$(cat "$BRIDGE_PID_FILE")" 2>/dev/null; then
    kill "$(cat "$BRIDGE_PID_FILE")" || true
    sleep 1
  fi
  rm -f "$BRIDGE_PID_FILE"

  local pid cmdline
  while IFS= read -r pid; do
    [[ -z "$pid" ]] && continue
    cmdline="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
    if [[ "$cmdline" == *"$BASE_DIR/linuxdo_h3_bridge.py"* ]]; then
      kill "$pid" || true
    fi
  done < <(
    ss -lntp "sport = :$BRIDGE_PORT" 2>/dev/null \
      | sed -n 's/.*pid=\([0-9]\+\).*/\1/p' \
      | sort -u
  )
  sleep 1
}

port_listener_pids() {
  ss -lntp "sport = :$LISTEN_PORT" 2>/dev/null \
    | sed -n 's/.*pid=\([0-9]\+\).*/\1/p' \
    | sort -u
}

ensure_port_available() {
  local pids pid cmdline
  pids="$(port_listener_pids || true)"
  [[ -z "$pids" ]] && return 0

  while IFS= read -r pid; do
    [[ -z "$pid" ]] && continue
    cmdline="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null || true)"
    if [[ "$cmdline" == *"$BASE_DIR/haproxy-dist/usr/sbin/haproxy"* ]] || [[ "$cmdline" == *"$BASE_DIR/Caddyfile"* ]]; then
      kill "$pid" || true
    else
      echo "port ${LISTEN_PORT} is occupied by pid=$pid" >&2
      echo "cmdline: $cmdline" >&2
      exit 1
    fi
  done <<< "$pids"

  sleep 1
  if [[ -n "$(port_listener_pids || true)" ]]; then
    echo "port ${LISTEN_PORT} is still busy after stopping old instance" >&2
    exit 1
  fi
}

if [[ "$(id -u)" -ne 0 ]] && need_root; then
  reexec_with_sudo "$@"
fi

"$BASE_DIR/gen_certs.sh" >/dev/null
if [[ -x "$BASE_DIR/install_linuxdo_ca.sh" ]]; then
  "$BASE_DIR/install_linuxdo_ca.sh" >/dev/null || true
fi
if [[ -x "$BASE_DIR/install_linuxdo_hosts.sh" ]]; then
  "$BASE_DIR/install_linuxdo_hosts.sh" >/dev/null
fi
mkdir -p /tmp/linuxdo-local-h3
ln -sfn "$BASE_DIR/certs" /tmp/linuxdo-local-h3/certs

if [[ ! -x "$BASE_DIR/haproxy-dist/usr/sbin/haproxy" ]]; then
  "$BASE_DIR/download_haproxy.sh"
fi

HAPROXY_BIN="$BASE_DIR/haproxy-dist/usr/sbin/haproxy"
HAPROXY_LD_LIBRARY_PATH="$BASE_DIR/haproxy-dist/opt/aws-lc/lib/x86_64-linux-gnu:$BASE_DIR/haproxy-dist/usr/lib/x86_64-linux-gnu:/lib/x86_64-linux-gnu"
BRIDGE_PYTHON="${BRIDGE_PYTHON:-$BASE_DIR/../.venv/bin/python}"

stop_existing_instance
stop_bridge_instance
ensure_port_available

nohup "$BRIDGE_PYTHON" \
  "$BASE_DIR/linuxdo_h3_bridge.py" \
  --listen-host "$BRIDGE_HOST" \
  --listen-port "$BRIDGE_PORT" \
  --doh-url "$DOH_URL" \
  >"$BRIDGE_LOG_FILE" 2>&1 &

BRIDGE_PID=$!
echo "$BRIDGE_PID" > "$BRIDGE_PID_FILE"
sleep 1

if ! kill -0 "$BRIDGE_PID" 2>/dev/null; then
  echo "bridge failed to start; check $BRIDGE_LOG_FILE"
  exit 1
fi

cat "$BASE_DIR/certs/linuxdo.crt" "$BASE_DIR/certs/linuxdo.key" > "$PEM_FILE"

GEN_ARGS=(
  --doh-url "$DOH_URL"
  --rrtypes "$RRTYPES"
  --listen-host "$LISTEN_HOST"
  --listen-port "$LISTEN_PORT"
  --linuxdo-bridge-host "$BRIDGE_HOST"
  --linuxdo-bridge-port "$BRIDGE_PORT"
  --pem-path "$PEM_FILE"
  --out "$CFG_FILE"
)

if [[ -n "$DOH_NAMES" ]]; then
  GEN_ARGS+=(--doh-names "$DOH_NAMES")
else
  GEN_ARGS+=(--doh-names-file "$DOMAINS_FILE")
fi

python3 "$BASE_DIR/gen_haproxy_cfg.py" "${GEN_ARGS[@]}" >/dev/null

env LD_LIBRARY_PATH="$HAPROXY_LD_LIBRARY_PATH" \
  "$HAPROXY_BIN" -c -f "$CFG_FILE"

nohup env LD_LIBRARY_PATH="$HAPROXY_LD_LIBRARY_PATH" \
  "$HAPROXY_BIN" -f "$CFG_FILE" \
  >"$LOG_FILE" 2>&1 &

PID=$!
echo "$PID" > "$PID_FILE"
sleep 1

if ! kill -0 "$PID" 2>/dev/null; then
  echo "haproxy failed to start; check $LOG_FILE"
  exit 1
fi

echo "haproxy_pid=$(cat "$PID_FILE")"
echo "haproxy_log=$LOG_FILE"
echo "bridge_pid=$(cat "$BRIDGE_PID_FILE")"
echo "bridge_log=$BRIDGE_LOG_FILE"
echo "listen=${LISTEN_HOST}:${LISTEN_PORT}"
echo "doh_url=$DOH_URL"
