#!/usr/bin/env python3
import argparse
import json
import threading
import time
import urllib.parse
import urllib.request
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from curl_cffi import CurlHttpVersion, CurlOpt, requests


HOP_BY_HOP_HEADERS = {
    "connection",
    "keep-alive",
    "proxy-authenticate",
    "proxy-authorization",
    "te",
    "trailer",
    "transfer-encoding",
    "upgrade",
}

STRIP_RESPONSE_HEADERS = {
    "alt-svc",
    "content-encoding",
    "content-length",
}


@dataclass
class DnsCacheEntry:
    authority: str
    ips: list[str]
    expires_at: float


@dataclass
class H3Response:
    status: int
    headers: list[tuple[str, str]]
    body: bytes


class H3Bridge:
    def __init__(self, authority: str, doh_url: str, timeout: float) -> None:
        self.default_authority = authority
        self.doh_url = doh_url
        self.timeout = timeout
        self._dns_lock = threading.Lock()
        self._dns_cache: dict[str, DnsCacheEntry] = {}
        self._dns_rr: dict[str, int] = {}

    def normalize_authority(self, authority: str | None) -> str:
        if not authority:
            return self.default_authority
        normalized = authority.strip().lower()
        if ":" in normalized:
            normalized = normalized.split(":", 1)[0]
        normalized = normalized.rstrip(".")
        if normalized == self.default_authority or normalized.endswith("." + self.default_authority):
            return normalized
        return self.default_authority

    def _ordered_ips(self, authority: str, ips: list[str]) -> list[str]:
        with self._dns_lock:
            rr = self._dns_rr.get(authority, 0)
            start = rr % len(ips)
            self._dns_rr[authority] = rr + 1
        return ips[start:] + ips[:start]

    def resolve_ips(self, authority: str, force_refresh: bool = False) -> list[str]:
        now = time.time()
        cached_ips: list[str] | None = None
        with self._dns_lock:
            cache = self._dns_cache.get(authority)
            stale_ips = list(cache.ips) if cache and cache.ips else []
            if not force_refresh and cache and cache.expires_at > now and cache.ips:
                cached_ips = list(cache.ips)
        if cached_ips:
            return self._ordered_ips(authority, cached_ips)

        params = urllib.parse.urlencode({"name": authority, "type": "A"})
        request = urllib.request.Request(
            f"{self.doh_url}?{params}",
            headers={"accept": "application/dns-json"},
        )
        try:
            with urllib.request.urlopen(request, timeout=8.0) as response:
                payload = json.load(response)
        except Exception:
            if stale_ips:
                return self._ordered_ips(authority, stale_ips)
            raise

        answers = payload.get("Answer", [])
        ips: list[str] = []
        ttl = 30
        for item in answers:
            data = item.get("data")
            if isinstance(data, str) and "." in data:
                ips.append(data)
                if isinstance(item.get("TTL"), int):
                    ttl = min(ttl, item["TTL"]) if ips[:-1] else item["TTL"]
        if not ips:
            raise RuntimeError("no A records returned from DoH")

        with self._dns_lock:
            self._dns_cache[authority] = DnsCacheEntry(
                authority=authority,
                ips=ips,
                expires_at=now + max(5, ttl),
            )
        return self._ordered_ips(authority, ips)

    def fetch(self, authority: str, method: str, path: str, headers: list[tuple[str, str]], body: bytes) -> H3Response:
        authority = self.normalize_authority(authority)
        request_headers = {key: value for key, value in headers}
        attempt_errors: list[str] = []

        for round_index in range(2):
            ips = self.resolve_ips(authority, force_refresh=round_index > 0)
            for ip in ips:
                try:
                    response = requests.request(
                        method=method,
                        url=f"https://{authority}{path}",
                        headers=request_headers,
                        data=body if body else None,
                        allow_redirects=False,
                        verify=False,
                        timeout=self.timeout,
                        http_version=CurlHttpVersion.V3ONLY,
                        curl_options={
                            CurlOpt.RESOLVE: [f"{authority}:443:{ip}"],
                        },
                    )
                    return H3Response(
                        status=response.status_code,
                        headers=list(response.headers.multi_items()),
                        body=response.content,
                    )
                except Exception as exc:
                    error = f"{ip}: {exc}"
                    attempt_errors.append(error)
                    print(
                        f"[bridge] upstream failure method={method} "
                        f"url=https://{authority}{path} ip={ip} error={exc}"
                    )

        raise RuntimeError(
            "all upstream h3 attempts failed: " + "; ".join(attempt_errors[-6:])
        )


class BridgeHandler(BaseHTTPRequestHandler):
    bridge: H3Bridge
    server_version = "linuxdo-h3-bridge/1.0"
    protocol_version = "HTTP/1.1"

    def do_GET(self) -> None:
        self._handle()

    def do_HEAD(self) -> None:
        self._handle()

    def do_OPTIONS(self) -> None:
        self._handle()

    def do_POST(self) -> None:
        self._handle()

    def do_PUT(self) -> None:
        self._handle()

    def do_PATCH(self) -> None:
        self._handle()

    def do_DELETE(self) -> None:
        self._handle()

    def handle(self) -> None:
        try:
            super().handle()
        except (BrokenPipeError, ConnectionResetError):
            pass

    def log_message(self, fmt: str, *args) -> None:
        print(f"[bridge] {self.address_string()} - {fmt % args}")

    def _handle(self) -> None:
        try:
            content_length = int(self.headers.get("Content-Length", "0") or "0")
            body = self.rfile.read(content_length) if content_length else b""
            headers = self._upstream_headers()
            response = self.bridge.fetch(
                authority=self.headers.get("Host"),
                method=self.command,
                path=self.path,
                headers=headers,
                body=body,
            )
            self.send_response(response.status)
            for key, value in response.headers:
                lower = key.lower()
                if lower in HOP_BY_HOP_HEADERS or lower in STRIP_RESPONSE_HEADERS:
                    continue
                self.send_header(key, value)
            self.send_header("Content-Length", str(len(response.body)))
            self.end_headers()
            if self.command != "HEAD":
                try:
                    self.wfile.write(response.body)
                except (BrokenPipeError, ConnectionResetError):
                    pass
        except Exception as exc:
            payload = f"bridge error: {exc}\n".encode()
            print(
                f"[bridge] request failure method={self.command} host={self.headers.get('Host')} "
                f"path={self.path} error={exc}"
            )
            try:
                self.send_response(502)
                self.send_header("Content-Type", "text/plain; charset=utf-8")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                if self.command != "HEAD":
                    self.wfile.write(payload)
            except (BrokenPipeError, ConnectionResetError):
                pass

    def _upstream_headers(self) -> list[tuple[str, str]]:
        headers: list[tuple[str, str]] = []
        for key, value in self.headers.items():
            lower = key.lower()
            if lower in HOP_BY_HOP_HEADERS or lower in {"host", "content-length"}:
                continue
            headers.append((lower, value))
        return headers


def main() -> int:
    parser = argparse.ArgumentParser(description="Local HTTP bridge to upstream H3 for linux.do")
    parser.add_argument("--listen-host", default="127.0.0.1")
    parser.add_argument("--listen-port", type=int, default=18080)
    parser.add_argument("--authority", default="linux.do")
    parser.add_argument("--doh-url", default="https://aaa.ddd.oaifree.com/query-dns")
    parser.add_argument("--timeout", type=float, default=90.0)
    args = parser.parse_args()

    BridgeHandler.bridge = H3Bridge(
        authority=args.authority,
        doh_url=args.doh_url,
        timeout=args.timeout,
    )
    server = ThreadingHTTPServer((args.listen_host, args.listen_port), BridgeHandler)
    print(f"bridge_listen={args.listen_host}:{args.listen_port} authority={args.authority}")
    server.serve_forever()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
