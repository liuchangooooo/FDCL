#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
PID_FILE="$BASE_DIR/haproxy.pid"
BRIDGE_PID_FILE="$BASE_DIR/bridge.pid"

if [[ ! -f "$PID_FILE" ]]; then
  echo "not running"
  exit 0
fi

PID="$(cat "$PID_FILE")"
if kill -0 "$PID" 2>/dev/null; then
  kill "$PID" || true
  sleep 1
fi

rm -f "$PID_FILE"

if [[ -f "$BRIDGE_PID_FILE" ]]; then
  BRIDGE_PID="$(cat "$BRIDGE_PID_FILE")"
  if kill -0 "$BRIDGE_PID" 2>/dev/null; then
    kill "$BRIDGE_PID" || true
    sleep 1
  fi
  rm -f "$BRIDGE_PID_FILE"
fi

echo "stopped"
