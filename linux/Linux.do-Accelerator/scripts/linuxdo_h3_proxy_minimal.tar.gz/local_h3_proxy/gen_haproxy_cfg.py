#!/usr/bin/env python3
import argparse
import concurrent.futures
import json
import re
import sys
import urllib.parse
import urllib.request
from dataclasses import dataclass


DEFAULT_DOH_URL = "https://aaa.ddd.oaifree.com/query-dns"
DEFAULT_DOH_NAMES = ("linux.do",)


@dataclass(frozen=True)
class DnsAnswer:
    ip: str
    rrtype: str
    ttl: int | None


def fetch_doh_answers(doh_url: str, name: str, rrtype: str) -> list[DnsAnswer]:
    params = urllib.parse.urlencode({"name": name, "type": rrtype})
    request = urllib.request.Request(
        f"{doh_url}?{params}",
        headers={"accept": "application/dns-json"},
    )
    with urllib.request.urlopen(request, timeout=8.0) as response:
        payload = json.load(response)

    answers: list[DnsAnswer] = []
    for item in payload.get("Answer", []):
        data = item.get("data")
        if not isinstance(data, str):
            continue
        ttl = item.get("TTL")
        answers.append(
            DnsAnswer(
                ip=data,
                rrtype=rrtype,
                ttl=ttl if isinstance(ttl, int) else None,
            )
        )
    return answers


def collect_upstreams(doh_url: str, rrtypes: list[str], names: list[str]) -> dict[str, list[DnsAnswer]]:
    def resolve_name(name: str) -> tuple[str, list[DnsAnswer]]:
        seen: set[str] = set()
        ordered: list[DnsAnswer] = []
        for rrtype in rrtypes:
            try:
                answers = fetch_doh_answers(doh_url, name, rrtype)
            except Exception as exc:
                print(f"warn: DoH lookup failed for {name} type={rrtype}: {exc}", file=sys.stderr)
                continue
            for answer in answers:
                if answer.ip in seen:
                    continue
                seen.add(answer.ip)
                ordered.append(answer)
        return name, ordered

    result: dict[str, list[DnsAnswer]] = {}
    workers = min(8, max(1, len(names)))
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = [executor.submit(resolve_name, name) for name in names]
        for future in concurrent.futures.as_completed(futures):
            name, ordered = future.result()
            result[name] = ordered
    result = {name: result.get(name, []) for name in names}
    return result


def normalize_backend_name(hostname: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", hostname.lower()).strip("_")


def format_server_addr(ip: str) -> str:
    if ":" in ip:
        return f"quic6@[{ip}]:443"
    return f"quic4@{ip}:443"


def render_cfg(
    listen_host: str,
    listen_port: int,
    pem_path: str,
    upstreams: dict[str, list[DnsAnswer]],
    linuxdo_bridge_host: str,
    linuxdo_bridge_port: int,
) -> str:
    lines = [
        "global",
        "  expose-experimental-directives",
        "  log stdout format raw local0",
        "  tune.quic.be.max-idle-timeout 120s",
        "  tune.quic.be.stream.rxbuf 1m",
        "  tune.quic.be.tx.udp-gso off",
        "",
        "defaults",
        "  mode http",
        "  log global",
        "  option httplog",
        "  timeout connect 10s",
        "  timeout client 60s",
        "  timeout server 60s",
        "  timeout http-request 15s",
        "",
        "frontend linuxdo_local",
        f"  bind {listen_host}:{listen_port} ssl crt {pem_path} alpn h2,http/1.1",
        "  http-response del-header alt-svc",
    ]

    names = list(upstreams.keys())
    default_backend = f"be_{normalize_backend_name(names[0])}" if names else "be_default"
    for name in names:
        acl_name = f"host_{normalize_backend_name(name)}"
        backend_name = f"be_{normalize_backend_name(name)}"
        lines.append(f"  acl {acl_name} hdr(host),lower -i {name}")
        lines.append(f"  use_backend {backend_name} if {acl_name}")
    lines.append(f"  default_backend {default_backend}")
    lines.append("")

    for name in names:
        backend_name = f"be_{normalize_backend_name(name)}"
        lines.append(f"backend {backend_name}")
        lines.append("  balance roundrobin")
        lines.append(f"  server local_bridge {linuxdo_bridge_host}:{linuxdo_bridge_port}")
        lines.append("")

    return "\n".join(lines) + "\n"


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate a HAProxy config with upstream IPs from DoH")
    parser.add_argument("--doh-url", default=DEFAULT_DOH_URL)
    parser.add_argument("--doh-names", default=",".join(DEFAULT_DOH_NAMES))
    parser.add_argument("--doh-names-file")
    parser.add_argument("--rrtypes", default="A")
    parser.add_argument("--listen-host", default="127.0.0.1")
    parser.add_argument("--listen-port", type=int, default=443)
    parser.add_argument("--linuxdo-bridge-host", default="127.0.0.1")
    parser.add_argument("--linuxdo-bridge-port", type=int, default=18080)
    parser.add_argument("--pem-path", required=True)
    parser.add_argument("--out", required=True)
    args = parser.parse_args()

    if args.doh_names_file:
        with open(args.doh_names_file, "r", encoding="utf-8") as fp:
            names = [line.strip() for line in fp if line.strip() and not line.lstrip().startswith("#")]
    else:
        names = [item.strip() for item in args.doh_names.split(",") if item.strip()]
    rrtypes = [item.strip().upper() for item in args.rrtypes.split(",") if item.strip()]
    upstreams = collect_upstreams(args.doh_url, rrtypes, names)
    if not any(upstreams.values()):
        print("No upstream IPs returned from DoH", file=sys.stderr)
        return 2

    content = render_cfg(
        args.listen_host,
        args.listen_port,
        args.pem_path,
        upstreams,
        args.linuxdo_bridge_host,
        args.linuxdo_bridge_port,
    )
    with open(args.out, "w", encoding="utf-8") as fp:
        fp.write(content)

    print(f"doh_url={args.doh_url}")
    print(f"doh_names={','.join(names)}")
    for name, answers in upstreams.items():
        summary = ",".join(answer.ip for answer in answers) if answers else "-"
        print(f"{name}={summary}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
