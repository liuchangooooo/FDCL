#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
CERT_DIR="$BASE_DIR/certs"
CFG="$BASE_DIR/linuxdo-openssl.cnf"

mkdir -p "$CERT_DIR"

if [[ ! -f "$CERT_DIR/rootCA.key" ]]; then
  openssl genrsa -out "$CERT_DIR/rootCA.key" 2048
fi

if [[ ! -f "$CERT_DIR/rootCA.crt" ]]; then
  openssl req -x509 -new -nodes \
    -key "$CERT_DIR/rootCA.key" \
    -sha256 -days 3650 \
    -subj "/C=CN/ST=Local/L=Local/O=Local LinuxDo H3 Proxy/OU=Local/CN=Local LinuxDo Root CA" \
    -out "$CERT_DIR/rootCA.crt"
fi

openssl genrsa -out "$CERT_DIR/linuxdo.key" 2048
openssl req -new -key "$CERT_DIR/linuxdo.key" -out "$CERT_DIR/linuxdo.csr" -config "$CFG"
openssl x509 -req \
  -in "$CERT_DIR/linuxdo.csr" \
  -CA "$CERT_DIR/rootCA.crt" \
  -CAkey "$CERT_DIR/rootCA.key" \
  -CAcreateserial \
  -out "$CERT_DIR/linuxdo.crt" \
  -days 825 \
  -sha256 \
  -extensions req_ext \
  -extfile "$CFG"

rm -f "$CERT_DIR/linuxdo.csr"

echo "Generated:"
echo "  Root CA : $CERT_DIR/rootCA.crt"
echo "  Leaf crt: $CERT_DIR/linuxdo.crt"
echo "  Leaf key: $CERT_DIR/linuxdo.key"
