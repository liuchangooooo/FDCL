#!/usr/bin/env bash
set -euo pipefail

MARK_BEGIN="# BEGIN linuxdo-local-h3"
MARK_END="# END linuxdo-local-h3"
BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
DOMAINS_FILE="$BASE_DIR/managed_domains.txt"

TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

cp /etc/hosts "$TMP"
python3 - "$TMP" "$DOMAINS_FILE" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
domains_path = Path(sys.argv[2])
text = path.read_text()
begin = "# BEGIN linuxdo-local-h3"
end = "# END linuxdo-local-h3"

lines = []
inside = False
for line in text.splitlines():
    if line.strip() == begin:
        inside = True
        continue
    if line.strip() == end:
        inside = False
        continue
    if not inside:
        lines.append(line)

domains = [
    line.strip()
    for line in domains_path.read_text().splitlines()
    if line.strip() and not line.lstrip().startswith("#")
]

lines.append(begin)
lines.extend(f"127.0.0.1 {domain}" for domain in domains)
lines.append(end)
path.write_text("\n".join(lines) + "\n")
PY
cp "$TMP" /etc/hosts
echo "updated /etc/hosts"
