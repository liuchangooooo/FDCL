#!/usr/bin/env bash
set -euo pipefail

BASE_DIR="$(cd "$(dirname "$0")" && pwd)"
CERT_DIR="$BASE_DIR/certs"
CA_CERT="$CERT_DIR/rootCA.crt"
CA_NAME="${CA_NAME:-Local LinuxDo Root CA}"
SYSTEM_CA_PATH="/usr/local/share/ca-certificates/linuxdo-local-h3.crt"

if [[ ! -f "$CA_CERT" ]]; then
  echo "missing CA cert: $CA_CERT" >&2
  exit 1
fi

get_target_home() {
  if [[ -n "${SUDO_USER:-}" ]] && [[ "${SUDO_USER}" != "root" ]]; then
    getent passwd "$SUDO_USER" | cut -d: -f6
    return
  fi
  printf '%s\n' "${HOME}"
}

import_nss_cert() {
  local db_dir="$1"
  mkdir -p "$db_dir"
  local db="sql:${db_dir}"
  if [[ ! -f "${db_dir}/cert9.db" ]]; then
    certutil -d "$db" -N --empty-password
  fi
  certutil -d "$db" -D -n "$CA_NAME" >/dev/null 2>&1 || true
  certutil -d "$db" -A -t "C,," -n "$CA_NAME" -i "$CA_CERT"
}

TARGET_HOME="$(get_target_home)"
if [[ -z "$TARGET_HOME" || ! -d "$TARGET_HOME" ]]; then
  echo "could not determine target home directory" >&2
  exit 1
fi

if [[ "$(id -u)" -eq 0 ]]; then
  install -m 0644 "$CA_CERT" "$SYSTEM_CA_PATH"
  update-ca-certificates
fi

if command -v certutil >/dev/null 2>&1; then
  import_nss_cert "$TARGET_HOME/.pki/nssdb"

  while IFS= read -r profile_db; do
    import_nss_cert "$(dirname "$profile_db")"
  done < <(
    find \
      "$TARGET_HOME/.mozilla/firefox" \
      "$TARGET_HOME/snap/firefox/common/.mozilla/firefox" \
      -maxdepth 2 -name cert9.db 2>/dev/null | sort -u
  )
fi

if [[ -n "${SUDO_UID:-}" ]] && [[ -n "${SUDO_GID:-}" ]]; then
  chown -R "${SUDO_UID}:${SUDO_GID}" "$TARGET_HOME/.pki" >/dev/null 2>&1 || true
  chown -R "${SUDO_UID}:${SUDO_GID}" "$TARGET_HOME/.mozilla/firefox" >/dev/null 2>&1 || true
  chown -R "${SUDO_UID}:${SUDO_GID}" "$TARGET_HOME/snap/firefox/common/.mozilla/firefox" >/dev/null 2>&1 || true
fi

echo "installed CA: $CA_NAME"
