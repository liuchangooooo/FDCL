#!/usr/bin/env bash
set -euo pipefail

TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT

cp /etc/hosts "$TMP"
python3 - "$TMP" <<'PY'
from pathlib import Path
import sys

path = Path(sys.argv[1])
text = path.read_text()
begin = "# BEGIN linuxdo-local-h3"
end = "# END linuxdo-local-h3"

lines = []
inside = False
for line in text.splitlines():
    if line.strip() == begin:
        inside = True
        continue
    if line.strip() == end:
        inside = False
        continue
    if not inside:
        lines.append(line)

path.write_text("\n".join(lines) + "\n")
PY
cp "$TMP" /etc/hosts
echo "cleaned /etc/hosts"
